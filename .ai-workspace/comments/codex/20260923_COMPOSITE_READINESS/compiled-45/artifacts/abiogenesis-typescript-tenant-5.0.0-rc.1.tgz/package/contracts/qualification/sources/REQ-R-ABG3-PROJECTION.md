# REQ-R-ABG3-PROJECTION — Replay And Projection

**Status**: Active
**Category**: Constraint / Guarantee
**Product behavior**: [Execution And Context Calculus](../../PRODUCT.md#execution-and-context-calculus); T-287 owner-directed Product/requirement re-entry.
**Date**: 2026-04-05
**Derives from**: [SPEC_METHOD.md](stdo://releases/v2.5.1-rc.1/standards/SPEC_METHOD.md), [ODD_METHOD.md](stdo://releases/v2.5.1-rc.1/standards/ODD_METHOD.md), [INTENT.md](../../INTENT.md) INT-001, [PRODUCT.md](../../PRODUCT.md)

---

## Purpose

Define replay-derived fluents and projections as the sole lawful current-state
surface over ABG runtime truth.

## Acceptance Criteria

**REQ-R-ABG3-PROJECTION-001**: Projection shall be deterministic. The same event stream and declared inputs shall always yield the same projection result.

**REQ-R-ABG3-PROJECTION-002**: Runtime state shall be derived from the admitted event history and its declared inputs. The live owner shall maintain that projection incrementally; cold acquisition and recovery shall reconstruct the equivalent committed runtime state. Replay-derived describes the source relation, not a requirement to repeat a whole-history fold on every handoff or read. ABG shall not write fluent state as a rival authority surface.

**REQ-R-ABG3-PROJECTION-003**: ABG shall provide explicit projections for at minimum `run`, `graph_call`, `frame`, and `continuation`.

**REQ-R-ABG3-PROJECTION-004**: If replay cannot determine admitted runtime state, including explicit unknown or unresolved dispositions, from the event history and its declared sources, the event/projection model is constitutionally incomplete. Reconstructing an historical observation shall not establish the present physical state of its workspace subject.

**REQ-R-ABG3-PROJECTION-005**: Snapshot, checkpoint, or state-summary surfaces may exist as replay aids, but they shall not override replay-derived truth.

**REQ-R-ABG3-PROJECTION-006**: Callable truth, frame truth, and continuation truth shall not be hidden as implicit side effects inside run projection alone.

**REQ-R-ABG3-PROJECTION-007**: ABG shall provide replay-derived projection over actor/process supervision events when process-boundary dispatch is used. The projection shall expose process identity when available, stream evidence references, latest heartbeat or liveness observation, timeout state, signal sequence, exit status, exit signal, runtime error, and final observed actor result.

**REQ-R-ABG3-PROJECTION-008**: Process liveness, timeout, and stream-observation state shall be projected from admitted actor/process events. A downstream product shall not infer child-process state from terminal transcript text, polling side effects, or product-local mutable controller state.

**REQ-R-ABG3-PROJECTION-009**: Retry-frontier projection shall preserve the full retry attempt frontier for the active traversal boundary, including prior attempt identities, reason classes, owner surfaces, source event kinds, and attempt coverage. A latest-only dossier or product-local summary shall not satisfy full-frontier projection.

**REQ-R-ABG3-PROJECTION-010**: A structural assertion that a supplied projection is full shall validate row shape, deterministic identity, reason-class coverage, and retry-attempt coverage. Closure-critical consumers should prefer replay-derived projections or compare supplied projections against replay-derived truth.

**REQ-R-ABG3-PROJECTION-011**: Public runtime summaries, CLI surfaces, and downstream consumer projections that describe traversal non-progress shall render the same admitted continuation disposition and `NextActionProjection`. A carrier may record process facts and `evaluateNext` may emit a candidate selection projection, but only ABG admission may make selection or continuation runtime truth; a projector shall decide neither. There shall be one authoritative admitted action truth for a given event stream and exact input basis.

**REQ-R-ABG3-PROJECTION-012**: Traversal modulation projection shall be deterministic over GTL qualifier truth, current basis, admitted schedule refs, admitted progress rows, backend progress classification, forced-review gates, and existing non-progress/foldback/reentry projections. Public summaries and downstream consumers shall not publish a rival next action for the same event stream.

**REQ-R-ABG3-PROJECTION-013**: `HoldsAt` truth shall be derived by replay over admitted runtime events, declared Event Calculus effects, initial fluent truth, clipping, and derived-fluent rules. Projection modules may present read models over those fluents, but shall not own untraceable rival transition law.

**REQ-R-ABG3-PROJECTION-014**: Temporal projection shall be a replay-derived read model over admitted timer, deadline-breach, and scheduled-continuation events. It may supply deadline-breach pressure and drift observations to `evalGap` and `evaluateNext`, but it shall not determine eligibility, select graph advancement, close vectors, or outrank admitted aggregate truth.

**REQ-R-ABG3-PROJECTION-015**: Schedule, SLA, and temporal drift shall feed a homeostatic projection/evaluation surface separate from traversal-completeness projection. Edge closure remains governed by existing ABG traversal and evaluator law.

**REQ-R-ABG3-PROJECTION-016**: ABG shall provide one replay-derived runtime liveness observer projection over admitted probe activity, actor/process lifecycle events, runtime asset observations, artifact observations, structured traversal observations, inactivity policy, external interruption evidence, and retry budget inputs. Runtime asset observations include event log append, ledger append/update, manifest creation/update, projection/report/dossier creation, archive/sidecar writes, and PTY or stream capture updates when they are used as activity evidence. Public runtime summaries, watchdog logic, and downstream consumers shall read liveness and disposition from that projection rather than recomputing it from local process state, file polling, transcript text, or harness timers.

**REQ-R-ABG3-PROJECTION-017**: The runtime liveness observer projection shall expose probe coverage, active systems, inactive systems, interrupted systems, last activity, last artifact observation, current lease state, hard-safety-cap state, and one runtime invocation disposition. The disposition shall distinguish continue waiting, controlled termination, retry, yield continuation, block, inspect archive, escalate, and policy reprice.

**REQ-R-ABG3-PROJECTION-018**: Overlay-frame projection shall be replay-derived from overlay-frame declaration and evaluation events plus admitted observed-state truth. A projection shall reject predicate evaluations whose satisfied or missing-ref state cannot be derived from the observed-state projection, and overlay completion shall not clear pressure unless declared clearing evidence is admitted or a declared no-close policy preserves the pressure.

**REQ-R-ABG3-PROJECTION-019**: ABG shall provide one replay-derived continuation-transition projection for the active traversal boundary when continuation, retry, liveness, assurance, or terminal fallback facts may affect the next runtime action. Typed admitted runtime facts and assurance fold outcomes outrank terminal retry fallback refs. Terminal retry refs are evidence and may select retry only when no higher-priority typed transition fact exists. Unknown or unsupported mixed states shall fail closed with provenance refs rather than dispatching a new worker attempt.

**REQ-R-ABG3-PROJECTION-020**: Evaluation scope refs used by evaluation, assurance, iteration, or progress read models shall be replay-derived or admitted facts bound to the current graph call, frame, graph function, graph vector, vector index, selected composition, and declared scope topology. Projection shall not synthesize scoped current-state truth from rendered prompts, diagnostic text, filenames, or product-local controller memory.

**REQ-R-ABG3-PROJECTION-021**: ABG shall provide a replay-derived executive
observation projection over existing graph-function environment, workspace
context, replay event refs, payload ledger refs, evidence refs, requirement
refs, residual pressure refs, continuation refs, and span-lineage refs. This
projection is an observation input to `evalGap` and the executive evaluator; it shall not emit
runtime events, write ledgers, mutate the observed graph/workspace, or create a
parallel observation/workspace ontology.

**REQ-R-ABG3-PROJECTION-022**: ABG shall project admitted `ProductAssetModel`, `ObservationSnapshot`, `GapPressureRow`, `TargetObligationBinding`, `PriorityProjection`, `EdgeFulfillmentLedger`, `EdgeClosureDecision`, and `NextActionProjection` truth with their exact program, workspace-binding, execution-basis, lineage, causal input, and source refs. A projection shall not synthesize a missing source carrier or transfer authority among model synthesis, gap evaluation, next-action evaluation, and action evaluation.

**REQ-R-ABG3-PROJECTION-023**: The public `project.read` family shall be a pure closed source/projection relation. In ABIogenesis 5.0 it may render catalog list/describe, status, result, evidence, replay, gaps, and lawful actions only from their owning admitted truth. It shall not evaluate gaps, determine action eligibility, rank or select actions, admit intent or evidence, invoke or continue work, append events, or decide closure. Observer-report, observer-drafts, and tuning-report projections, including tuning-draft transition exclusions, are reserved for the planned 5.1 observer/tuner Product.

**REQ-R-ABG3-PROJECTION-024**: A newer `ObservationSnapshot` under the same immutable workspace binding and execution basis may invalidate and recompute dependent model, gap, target-binding, priority, and next-action projections. Projection shall treat that as ordinary observation progress, never as a workspace rebind or `basis_fork_detected`; an authority change remains governed by binding and continuation law.

**REQ-R-ABG3-PROJECTION-025**: Established projection facts shall be reusable
under their exact subject, basis, scope, provenance and validity conditions.
An internal function or role boundary shall not by itself trigger complete
history reconstruction or reauthentication. A whole-history dependency shall
identify its governing relation and extent. Qualification shall compare live
and cold results at the same committed boundary, preserving required checks
at actual acquisition, invalidation, authority and effect boundaries.

**REQ-R-ABG3-PROJECTION-026**: When effects may have occurred and a required
successor observation is unavailable, projection shall withdraw dependent
currentness over potentially affected scope while preserving unaffected facts
and the original failure. Unknown physical state shall not become unchanged
state, rollback or a fabricated successor observation.
