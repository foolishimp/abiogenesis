# GTL Requirement Families

This domain owns the constitutional language and graph law for GTL 3.

GTL is an LLM-first, graph-first, algebraic governance control language with
implementation-independent canonical declaration data and native typed
authoring APIs in each conforming build tenant.

Fast reload anchor:

- `REQ-L-GTL3-CONTRACT-LAW-API.md` states GTL as the constitutional
  contract-law API and graph algebra, then indexes the detailed requirement
  families below. Load it first when reviewing GTL capability, ABG program
  admission, downstream graph-asset conformance, target-carrier law, prompt
  asset law, hook/plugin boundaries, `F_D`/`F_P`/`F_H` composition, recursive
  graph functions, ABG runtime-operation configuration, or external tool gates.

Use these families for semantic truth about language identity, attrs, contexts,
graphs, graph vectors, graph functions, hook surfaces, semantic work
declarations, algebra, publication boundaries, epistemic notation over the
ratified ontology, and the GTL/ABG boundary.

## Scope

- language identity, declarative form, attrs, contexts, and engine boundary
- contract-law API identity, reload boundary, and ownership split across GTL,
  ABG, and downstream products
- complete GTL language configuration for product-visible graph-program
  elements validated as GTL, traversed by HoG, and admitted as runtime truth
  by ABG
- graph structure, typed loci, interfaces, graph vectors, and identities
- typed asset-surface interfaces, including renderer-backed asset contracts
- operators, evaluators, rules, and governance hook surfaces
- graph functions, selection boundaries, synthesis, and bounded sub-work
- algebraic composition, substitution, recursion, and higher-order graph
  operations
- epistemic notation that distinguishes transform candidates, evaluator
  findings, ABG admission, runtime ledgers/projections, and consequence
  projections without adding new topology objects or runtime carriers
- semantic work declarations and module publication boundaries
- requirement declaration wrappers over GTL publication, graph-function,
  graph-vector, context, hook, and asset-surface law

## Families

- `REQ-L-GTL3-CONTRACT-LAW-API.md`
- `REQ-L-GTL3-LANGUAGE-CAPABILITY-MODEL.md`
- `REQ-L-GTL3-REQUIREMENTS-ALGEBRA.md`
- `REQ-L-GTL3-LANGUAGE.md`
- `REQ-L-GTL3-ATTRS.md`
- `REQ-L-GTL3-CONTEXT.md`
- `REQ-L-GTL3-GRAPH.md`
- `REQ-L-GTL3-NODE.md`
- `REQ-L-GTL3-ASSET-SURFACE.md`
- `REQ-L-GTL3-GRAPHVECTOR.md`
- `REQ-L-GTL3-INTERFACE.md`
- `REQ-L-GTL3-OPERATOR.md`
- `REQ-L-GTL3-EVALUATOR.md`
- `REQ-L-GTL3-RULE.md`
- `REQ-L-GTL3-GRAPHFUNCTION.md`
- `REQ-L-GTL3-HOOKS.md`
- `REQ-L-GTL3-COMPUTE-NOTATION.md`
- `REQ-L-GTL3-ROLE.md`
- `REQ-L-GTL3-JOB.md`
- `REQ-L-GTL3-IDENTITY.md`
- `REQ-L-GTL3-COMPOSE.md`
- `REQ-L-GTL3-C-ALGEBRA.md`
- `REQ-L-GTL3-SUBSTITUTE.md`
- `REQ-L-GTL3-RECURSE.md`
- `REQ-L-GTL3-HOF.md`
- `REQ-L-GTL3-LAWS.md`
- `REQ-L-GTL3-MODULE.md`
- `REQ-L-GTL3-SELECTION-BOUNDARY.md`
- `REQ-L-GTL3-SUBWORK.md`
- `REQ-L-GTL3-SYNTHESIS.md`
