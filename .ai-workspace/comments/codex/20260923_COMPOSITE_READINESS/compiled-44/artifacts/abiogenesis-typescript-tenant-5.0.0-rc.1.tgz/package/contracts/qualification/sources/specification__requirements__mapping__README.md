# Mapping Requirement Families

This domain owns the bridge law between GTL constitutional declarations and ABG runtime realization.

Use these families where the project needs explicit mapping, capability, or provenance rules that sit between language law and engine behavior.

## Scope

- capability translation
- GTL-to-runtime mapping surfaces
- bridge provenance requirements

## Families

- `REQ-M-GTL3-MAPPING.md`
- `REQ-M-GTL3-PROGRAM-TRAVERSAL.md`
- `REQ-M-GTL3-PROVENANCE.md`
- `REQ-M-GTL3-CAPABILITY.md`
