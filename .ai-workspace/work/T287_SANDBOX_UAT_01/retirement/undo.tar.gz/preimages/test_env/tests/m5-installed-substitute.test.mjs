// These legacy Public-setup cases are outside the selected expunction assurance.
// Their protocol predates current DefinitionCall; no successor qualification is claimed.
// The fixture below is independently owned test data, never an ABG package capability.
import { prepareLanguageStructuralFixture } from "../support/language-structural-fixture.mjs";
import { constructStructuralInput } from "../fixtures/language-structural/program.mjs";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

import {
  buildRootCliScenario,
  runInstalledCli,
  setupInstalledCliHarness,
} from "../support/root-cli-environment.mjs";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const PROGRAM_REF = "program://abi5-tests/structural/substitute@5";
const GRAPH_FUNCTION_REF =
  "graph-function://abi5-tests/structural/substitute@5";

async function readEvents(path) {
  return (await readFile(path, "utf8"))
    .trim()
    .split(/\r?\n/u)
    .map((line) => JSON.parse(line));
}

test("M5 installed HoG traverses one natively substituted GraphFunction", async (context) => {
  const harness = await setupInstalledCliHarness(context, root, {
    prepareFixture: prepareLanguageStructuralFixture,
  });
  const scenario = await buildRootCliScenario(
    harness,
    "m5-substitute",
    (payload) => payload,
    {
      catalogApplications: [],
      input: constructStructuralInput(),
      programRef: PROGRAM_REF,
      catalogHandle: GRAPH_FUNCTION_REF,
      allowlist: [GRAPH_FUNCTION_REF],
    },
  );
  const run = await runInstalledCli(harness, scenario);

  assert.equal(run.exitCode, 0, run.stdout);
  assert.equal(run.outcomes.length, 7);
  assert.equal(run.outcomes.every((outcome) => outcome.disposition === "succeeded"), true);
  assert.deepEqual(run.outcomes[6].result, {
    kind: "data_output",
    schemaVersion: "5.0.0",
    message: "World",
  });
  assert.equal(run.outcomes[6].replayAgreement, true);

  const events = await readEvents(scenario.eventLogPath);
  const cCalls = events.filter((event) => event.kind === "c_call_opened");
  const fibres = events.filter((event) => event.kind === "c_call_fibre_selected");
  const routes = events.filter((event) => event.kind === "traversal_route_admitted");
  assert.deepEqual(
    cCalls.map((event) => event.payload.programLocusRef),
    [
      "locus://abi5-tests/structural/graph-edge/normalize@5",
      "locus://abi5-tests/structural/substitute/pass@5",
      "locus://abi5-tests/structural/graph-edge/render@5",
    ],
  );
  assert.equal(fibres.length, 3);
  assert.equal(fibres[0].payload.compositionRef, fibres[2].payload.compositionRef);
  assert.notEqual(fibres[0].payload.compositionRef, fibres[1].payload.compositionRef);
  assert.equal(new Set(fibres.map((event) => event.payload.compositionRef)).size, 2);
  assert.equal(
    fibres.every((event) =>
      /^graph-function-application:\/\/abiogenesis\//u.test(
        event.payload.compositionRef,
      )),
    true,
  );
  assert.deepEqual(
    routes.map((event) => event.payload.routeKind),
    ["advance", "advance", "terminal"],
  );
  assert.notEqual(routes[0].payload.targetCursorRef, null);
  assert.notEqual(routes[1].payload.targetCursorRef, null);
  assert.equal(routes[2].payload.targetCursorRef, null);
  assert.equal(events.at(-1).kind, "run_closed");
  assert.equal(JSON.stringify(events).includes("CompiledCProgramPlan"), false);
  assert.equal(JSON.stringify(events).includes("compiled_execution"), false);
});
